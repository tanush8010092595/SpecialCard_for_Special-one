
let idx=0;
const pages=[...document.querySelectorAll('.page')];
function nextPage(){
 pages[idx].classList.remove('active');
 idx=Math.min(idx+1,pages.length-1);
 pages[idx].classList.add('active');
 if(idx===2)type();
}
const msg="No matter what tomorrow brings, you'll always have a place in my heart. Happy Birthday ❤️";
let i=0,started=false;
function type(){
 if(started)return; started=true;
 (function t(){
  if(i<msg.length){
    typing.textContent+=msg[i++];
    setTimeout(t,35);
  }
 })();
}
