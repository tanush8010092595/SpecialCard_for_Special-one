# Eternal Love v7

Final demo version.

To make it premium:
- Replace the photo placeholder with your image.
- Add your own music in assets/.
- Integrate GSAP, Three.js, tsParticles, Lottie and canvas-confetti for cinematic effects.
