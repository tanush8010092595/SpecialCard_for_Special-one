
document.getElementById('celebrate').onclick=()=>{
  document.getElementById('ending').classList.remove('hidden');
  document.getElementById('celebrate').textContent='❤️ Forever Yours';
  alert('Replace the photo box with your image and add fireworks/confetti libraries for an even richer celebration.');
};
