# Eternal Love v6
Add your own assets/music.mp3 and replace the photo placeholder.