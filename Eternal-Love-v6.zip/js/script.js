
const text=`No matter where life takes us, I hope today reminds you how deeply you are appreciated. Happy Birthday, Soumiii ❤️`;
let i=0;
(function t(){
 if(i<text.length){
  msg.textContent+=text[i++];
  setTimeout(t,30);
 }
})();
musicBtn.onclick=()=>{
 const a=document.getElementById('bgm');
 if(a.paused){a.play().catch(()=>alert('Add assets/music.mp3 to enable music.'));musicBtn.textContent='🔇 Mute';}
 else{a.pause();musicBtn.textContent='🎵 Music';}
}
reveal.onclick=()=>{
 surprise.classList.remove('hidden');
 document.querySelector('.card').style.display='none';
}
