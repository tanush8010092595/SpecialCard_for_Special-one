
function next(n){
document.querySelector('.page.active').classList.remove('active');
document.getElementById('p'+n).classList.add('active');
}
