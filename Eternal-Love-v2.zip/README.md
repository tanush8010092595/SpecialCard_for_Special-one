# Eternal Love v2
Basic envelope animation starter.