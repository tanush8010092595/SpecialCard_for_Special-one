
const btn=document.getElementById('heart');
const env=document.getElementById('envelope');
const hint=document.getElementById('hint');
btn.onclick=()=>{
 btn.style.display='none';
 hint.textContent='Opening your magical letter...';
 env.classList.remove('hidden');
 setTimeout(()=>env.classList.add('open'),200);
};
