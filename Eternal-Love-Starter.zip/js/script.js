document.getElementById('startBtn').onclick=()=>{
alert('Envelope animation will be added in the next module.');
};