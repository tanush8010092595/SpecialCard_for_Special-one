
const btn=openBtn,env=document.getElementById('env');
btn.onclick=()=>{
 btn.style.display='none';
 env.style.display='block';
 setTimeout(()=>env.classList.add('open'),200);
 setTimeout(()=>{
   screen1.classList.remove('active');
   card.classList.add('active');
 },1400);
}
next.onclick=()=>alert('Version 4: "Enjoy your special day..." page and elegant transitions.');
