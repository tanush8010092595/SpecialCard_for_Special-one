
const msg=`Happy Birthday! Today is all about celebrating the wonderful person you are.
May every smile, dream and beautiful moment stay with you forever.
Thank you for being someone truly special. ❤️`;

let i=0;
function type(){
 if(i<msg.length){
   document.getElementById('text').textContent+=msg.charAt(i++);
   setTimeout(type,35);
 }
}
type();

document.getElementById('music').onclick=()=>{
 alert('In Version 6 this button will play romantic background music.');
};
