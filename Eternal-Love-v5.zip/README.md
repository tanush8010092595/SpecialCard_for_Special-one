# Eternal Love v5
Typewriter letter with decorative petals.