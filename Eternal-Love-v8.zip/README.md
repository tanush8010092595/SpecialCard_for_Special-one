# Eternal Love v8

Place your image as assets/photo.jpg. This is the final demo milestone before a full production-grade rebuild.