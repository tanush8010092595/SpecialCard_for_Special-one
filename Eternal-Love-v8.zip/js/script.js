
const msg="No matter how many birthdays come, you will always have a special place in my heart. Happy Birthday! ❤️";
let i=0;
(function type(){
 if(i<msg.length){document.getElementById('type').textContent+=msg[i++];setTimeout(type,35);}
})();
document.getElementById('finalBtn').onclick=()=>document.getElementById('final').classList.remove('hidden');
