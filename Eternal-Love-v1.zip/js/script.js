
document.getElementById('start').addEventListener('click',()=>{
 alert('Version 2 will open a realistic animated envelope.');
});
